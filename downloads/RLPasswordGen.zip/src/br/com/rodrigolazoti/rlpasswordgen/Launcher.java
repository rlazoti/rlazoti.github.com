package br.com.rodrigolazoti.rlpasswordgen;

import br.com.rodrigolazoti.rlpasswordgen.forms.frmMain;

public class Launcher {

	public static void main(String[] args) {
		new frmMain();
	}
}
