package br.com.rodrigolazoti.rlpasswordgen.forms;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import br.com.rodrigolazoti.rlpasswordgen.library.PasswordGen;

@SuppressWarnings("serial")
public class frmMain extends JFrame {

	private JButton btnFechar;
	private JButton btnGerar;
	private JLabel jLabel1;
	private JLabel jLabel2;
	private JLabel jLabel3;
	private JLabel jLabel4;
	private JLabel jLabel5;
	private JSeparator jSeparator1;
	private JSpinner spnDigito;
	private JTextField txtChave;
	private JTextField txtSenha;

	public frmMain() {
		createComponents();
		initComponents();
		setEventsToComponents();
		setVisible(true);
	}

	private void createComponents() {
		btnFechar = new JButton();
		btnGerar = new JButton();
		txtChave = new JTextField();
		txtSenha = new JTextField();
		spnDigito = new JSpinner();
		jLabel1 = new JLabel();
		jLabel2 = new JLabel();
		jLabel3 = new JLabel();
		jLabel4 = new JLabel();
		jLabel5 = new JLabel();
		jSeparator1 = new JSeparator();
	}

	private void initComponents() {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(385, 300);
		setTitle("RL PasswordGen 1.0");
		setResizable(false);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);

		btnFechar.setText("Fechar");
		getContentPane().add(btnFechar);
		btnFechar.setBounds(246, 230, 75, 23);
		btnFechar.setToolTipText("Encerra o programa.");
		btnFechar.setCursor(new Cursor(Cursor.HAND_CURSOR));

		btnGerar.setText("Gerar Senha");
		getContentPane().add(btnGerar);
		btnGerar.setBounds(120, 230, 120, 23);
		btnGerar.setToolTipText("Gera uma nova senha com valores aleatórios.");
		btnGerar.setCursor(new Cursor(Cursor.HAND_CURSOR));

		getContentPane().add(jLabel5);
		jLabel5.setBounds(15, 200, 370, 14);
		jLabel5.setFont(new Font("Arial", 1, 9));
		jLabel5.setText("Rodrigo Lazoti. www.rodrigolazoti.com.br - contato@rodrigolazoti.com.br");

		getContentPane().add(txtChave);
		txtChave.setBounds(200, 70, 120, 19);

		jLabel1.setText("Chave de Gera\u00e7\u00e3o da Senha:");
		getContentPane().add(jLabel1);
		jLabel1.setBounds(30, 70, 170, 14);

		getContentPane().add(spnDigito);
		spnDigito.setBounds(200, 90, 120, 21);

		jLabel2.setText("Quantidade D\u00edgitos da Senha:");
		getContentPane().add(jLabel2);
		jLabel2.setBounds(30, 90, 170, 14);

		jLabel4.setText("Senha Gerada:");
		getContentPane().add(jLabel4);
		jLabel4.setBounds(110, 120, 100, 14);
		jLabel4.setForeground(Color.blue);

		getContentPane().add(txtSenha);
		txtSenha.setBounds(200, 120, 120, 19);
		txtSenha.setEditable(false);
		txtSenha.setForeground(Color.blue);
		txtSenha.setCursor(new Cursor(Cursor.TEXT_CURSOR));

		jLabel3.setText("RL PasswordGen 1.0 - Gerador de Senhas Aleat\u00f3rias");
		getContentPane().add(jLabel3);
		jLabel3.setBounds(10, 10, 360, 17);
		jLabel3.setFont(new Font("Tahoma", 1, 14));
		jLabel3.setForeground(Color.lightGray);


		getContentPane().add(jSeparator1);
		jSeparator1.setBounds(0, 215, 380, 20);
	}

	protected void setEventsToComponents() {
		btnGerar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				btnGerarOnClick(evt);
			}
		});

		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				btnFecharOnClick(evt);
			}
		});
	}

	private boolean validaQuantidadeDigitos() {
		if (Integer.parseInt(spnDigito.getValue().toString()) < 3) {
			JOptionPane.showMessageDialog(null,
					"A Senha deve ter no mínimo 3 dígitos.", "Atenção", 2);
      return false;
		}
		else {
			return true;
		}
	}

	private void btnGerarOnClick(ActionEvent evt) {
    if (!validaQuantidadeDigitos()) {
    	return;
    }

    int digitos = Integer.parseInt(spnDigito.getValue().toString());
    String chave = txtChave.getText();

    txtSenha.setText( PasswordGen.gerarSenha(digitos, chave) );
	}

	private void btnFecharOnClick(ActionEvent evt) {
		dispose();
	}
}